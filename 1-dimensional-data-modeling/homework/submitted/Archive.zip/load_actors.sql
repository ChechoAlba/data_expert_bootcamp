--select min(year), max(year)
--from actor_films
--1970 to 2021
INSERT INTO actors
WITH years AS (
    SELECT *
    FROM GENERATE_SERIES(1970, 2021) AS current_year
),a AS (
    SELECT
        actor,
        MIN(year) AS first_year
    FROM actor_films
    GROUP BY actor
), actors_and_years as (
	SELECT *
    FROM a
    JOIN years y
    ON a.first_year <= y.current_year
),windowed AS (
    SELECT
        aay.actor,
        aay.current_year,
        ARRAY_REMOVE(
            ARRAY_AGG(
                CASE
                    WHEN af.year IS NOT NULL
                        THEN row(
						af.film,
						af.votes,
						af.rating,
						af.filmid
					)::film_stats
                END)
            OVER (PARTITION BY aay.actor ORDER BY COALESCE(aay.current_year, af.year)),
            NULL
        ) AS films,
        case when aay.current_year = af.year then true else false end as is_active,
        AVG(af.rating) over (partition by aay.actor ORDER BY COALESCE(aay.current_year, af.year)) as rating_avg,
        row_number () OVER (PARTITION BY aay.actor,aay.current_year ORDER BY aay.current_year) as row_number
    FROM actors_and_years aay
    LEFT JOIN actor_films af
        ON aay.actor = af.actor
        AND aay.current_year = af.year
    ORDER BY aay.actor, af.year
)
select w.actor,
w.films,
w.is_active,
w.current_year,
case when w.rating_avg >8 then 'star'
when w.rating_avg >7 and w.rating_avg <=8 then 'good'
when w.rating_avg >6 and w.rating_avg <=7 then 'good'
else 'bad'
end as quality_class
from windowed w
where row_number=1
order by actor,current_year