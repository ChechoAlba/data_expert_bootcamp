create table actors_history_scd
(
	actor text,
	quality_class performance_class,
	is_active boolean,
	start_date integer,
	end_date integer,
	current_year INTEGER
);
