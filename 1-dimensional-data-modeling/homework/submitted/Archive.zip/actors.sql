 CREATE TYPE film_stats AS (
                         film TEXT,
                         votes INTEGER,
                         rating REAL,
                         filmid TEXT
                       );
 CREATE TYPE performance_class AS
     ENUM ('star', 'good', 'average', 'bad');


 CREATE TABLE actors (
     actor TEXT,
     films film_stats[],
     quality_class performance_class,
     is_active BOOLEAN,
     current_year INTEGER,
     PRIMARY KEY (actor, current_year)
 );



